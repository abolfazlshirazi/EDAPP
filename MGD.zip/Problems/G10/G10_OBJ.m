function y = G10_OBJ(x)
    % Problem:          G10
    % Function Type:    Objectives
    % Date:             Nov. 2019
    % By:               Abolfazl Shirazi (ashirazi@bcamath.org)
    
    y = x(1)+x(2)+x(3);
end