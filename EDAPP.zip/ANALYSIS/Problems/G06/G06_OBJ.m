function y = G06_OBJ(x)
    % Problem:          G06
    % Function Type:    Objectives
    % Date:             Nov. 2019
    % By:               Abolfazl Shirazi (ashirazi@bcamath.org)
    
    y = (x(1)-10)^3+(x(2)-20)^3;
end