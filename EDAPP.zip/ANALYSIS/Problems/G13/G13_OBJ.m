function y = G13_OBJ(x)
    % Problem:          G13
    % Function Type:    Objectives
    % Date:             Nov. 2019
    % By:               Abolfazl Shirazi (ashirazi@bcamath.org)
    
    y = exp(prod(x));
end