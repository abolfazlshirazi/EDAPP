function y = G11_OBJ(x)
    % Problem:          G11
    % Function Type:    Objectives
    % Date:             Nov. 2019
    % By:               Abolfazl Shirazi (ashirazi@bcamath.org)
    
    y = x(1)^2+(x(2)-1)^2;
end