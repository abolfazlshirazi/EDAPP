function result=cauchy_rand(x0,y)

    x=rand;
    result=tan((x-1/2)*pi)*y+x0;



end